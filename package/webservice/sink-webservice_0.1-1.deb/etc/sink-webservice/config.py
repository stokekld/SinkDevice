import os

DEBUG = True
PORT = 8000
HOST = '0.0.0.0'
BASEDIR = os.path.dirname(os.path.realpath(__file__))
