from pymongo import MongoClient

db = MongoClient().Sink


